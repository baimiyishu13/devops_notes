深入了解 Ansible，学习 Ansible/DevOps/自动化
学到什么
了解 Ansible 模块。Ansible Playbooks 的结构、Ansible Playbooks 的创建和执行、Ansible Facts 和 Jinja2 模板
高级主题 – 内置模块、动态清单、并行循环、条件语句、任务委派、魔术变量、Vault、创建模块和插件
构建 Ansible playbooks：包含、角色、标签
将 Ansible 与云服务和容器、AWS 和 Docker结合使用 使用 Ansible 进行
故障排除
使用 Ansible 进行验证和测试（以及最佳实践）
